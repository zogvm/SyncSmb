package com.example.androidnotification;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore.Audio;
import android.text.StaticLayout;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RemoteViews;
import android.widget.SeekBar;
import android.widget.TextView;
/**
 * Notification
 * @author Administrator
 *
 */
public class MainActivity extends Activity {
	
	//BaseNotification
	private Button bt01;
	
	//UpdateBaseNotification
	private Button bt02;
	
	private static Context sContext = null;
	
	public static Context getContext() {
		return sContext;
	}
	
	@Override
	 public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        /*加载页面*/
	        setContentView(R.layout.activity_main);
	        
	        sContext = this;
	        init();
	}

	
	private void init() {
		bt01 = (Button)findViewById(R.id.le10bt01);
		bt02 = (Button)findViewById(R.id.le10bt02);

		bt01.setOnClickListener(onclick);
		bt02.setOnClickListener(onclick);

	}
	OnClickListener onclick = new OnClickListener() {
		@Override
		public void onClick(View v) {
			switch(v.getId()) {
				case R.id.le10bt01:			
					int delaytime = 5*1000;
					PushService.addNotification(delaytime,"tick","title","text");
					break;
					
				case R.id.le10bt02:
					PushService.cleanAllNotification();
					break;	
			}
		}
	};
	
	public boolean onKeyDown(int keyCode, KeyEvent event)  
    {  
        if (keyCode == KeyEvent.KEYCODE_BACK )  {
        	//System.exit(0);
        	android.os.Process.killProcess(android.os.Process.myPid());
        }          
        return false;       
    } 
	
}